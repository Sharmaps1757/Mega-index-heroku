# phy ( all derivations , theory reading from a book )

- [ ]  Electric Charges and Fields
- [ ]  Electrostatic Potential and Capacitance
- [ ]  Current Electricity
- [ ]  Moving Charges and Magnetism
- [ ]  Magnetism and Matter
- [ ]  Electromagnetic Induction
- [ ]  Alternating Current
- [ ]  Electromagnetic Waves
- [ ]  Ray Optics and Optical Instruments
- [ ]  Wave Optics
- [ ]  Dual Nature of Radiation and Matter
- [ ]  Atoms
- [ ]  Nuclei
- [ ]  Semiconductor Electronics: Materials, Devices and Simple Circuits