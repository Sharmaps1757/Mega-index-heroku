# TEST 9

Date: November 17, 2024
Tags: Not started

PHY - Dual Nature

Chem - Chemical Kinetics , Electro Chemistry , Metallurgy

Maths - AOD , Maxima and Minima

Marks Obtained - Paper 1 

| PAPER | PHY | CHEM | MATHS | TOTAL | MAX  |
| --- | --- | --- | --- | --- | --- |
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |