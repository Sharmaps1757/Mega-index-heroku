# TeeShopper - Design and Sell T-Shirts | Print On Demand

Tags: Price Tamper
+-: Not started
ADMIN PANEL: Not started
C2S: Not started
Gateway: paytm
SQLI: Not started
Tamper: Done
trick : Tamper in paytm