# FST 9

Date: December 9, 2024
Tags: Not started

Marks Obtained 

| PAPER | PHY | CHEM | MATHS | TOTAL | MAX  |
| --- | --- | --- | --- | --- | --- |
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |