# FST 6

Date: December 6, 2024
Tags: Not started

Marks Obtained 

| PAPER | PHY | CHEM | MATHS | TOTAL | MAX  |
| --- | --- | --- | --- | --- | --- |
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |