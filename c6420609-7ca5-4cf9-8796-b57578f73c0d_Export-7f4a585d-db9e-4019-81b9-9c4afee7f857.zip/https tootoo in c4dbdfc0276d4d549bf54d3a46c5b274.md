# https://tootoo.in/

Tags: otp bypass, shows payment complete without paying
+-: Not started
ADMIN PANEL: Not started
C2S: Not started
Gateway: razorpay 
SQLI: Not started
Tamper: Not started
trick : change payment to razorpay from cod in request