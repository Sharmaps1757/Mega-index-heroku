# FST 1

Date: December 1, 2024
Tags: Not started

Marks Obtained 

| PAPER | PHY | CHEM | MATHS | TOTAL | MAX  |
| --- | --- | --- | --- | --- | --- |
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |