# Brain Dump

<aside>
🍀 Just write it out already ~

</aside>

- “my life sucks at night i try to finish it”
- “i would rather scream than , use you as my remedy”
- “ik my life is hell without you , but it’s still better then living in the delusion that you’d be with me someday <3”
- “sirf tu hi ek whi thi , tere alawa koi nhi”
- “don’t get too attached to something that isn’t your”
- “labon pe mere ye kahani , dastan jo h purani , saath hum rahenge y umeed krke baithe the , daga k is pahaar m , baja rha guitar m”
- “tum ho to , m rhunga , rehni zaroorat meri , chahe bolo ya na bolo , tum to rahogi meri”
- “zindagi kya h ? , yaadon ki mala h , yaadon k ilawa kbhi kuxch baaki raha h ?”
- “But I hear you calling my name , Is it because of the fame, or are you feeling the same?”
- “na m wada krta hoon , na m bhula krta , tu h to sb rasto pe , m kya dhoondha krta”
- “yun tera hona bhi , aur tanha krta”
- “muh mod k jo tu mujhse chli , mil gya mujhe bahana”
- “she didn’t even notice , that she called me by his name”
- “how could you stab me in the back , i thought you were better than that”
- “was i enough for you ? , doing everything i was told to do”
- “So , how would you feel , if i would steal , your heart away , along with this pain , coz you give me butterflies and i , i need you to stay”
- “i know you tried , but it won’t end”
- “baby i need you in my life , please babe don’t go switching sides”
- “please don’t take your love away”
- “i m not suicidal , i don’t wanna fcking die”
- “i hope that you don’t get bored of me or my clothes”
- “when i hear you say my name , tell me everything’s ohk , i forget about the world , i forget about the pain”
- “Baby, I don’t wanna go home tonight”
- “i see two moons and nothing moreee”
- “heard that you’ve been doing well , i wonder who you’re with”