# NLM AND FRICTION

1 TIME: Done
PYQ: Not started