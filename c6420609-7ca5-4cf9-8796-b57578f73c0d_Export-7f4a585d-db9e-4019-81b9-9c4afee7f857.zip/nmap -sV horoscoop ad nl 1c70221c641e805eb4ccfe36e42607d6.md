# nmap -sV horoscoop.ad.nl

Starting Nmap 7.95 ( [https://nmap.org](https://nmap.org/) ) at 2025-03-31 10:57 IST
Nmap scan report for [horoscoop.ad.nl](http://horoscoop.ad.nl/) (185.71.61.104)
Host is up (0.092s latency).
Other addresses for [horoscoop.ad.nl](http://horoscoop.ad.nl/) (not scanned): 2a03:38a0:61:104::1
rDNS record for 185.71.61.104: [godthelpprod02.cobytes.io](http://godthelpprod02.cobytes.io/)
Not shown: 989 filtered tcp ports (no-response)
PORT     STATE  SERVICE   VERSION
20/tcp   closed ftp-data
21/tcp   open   ftp       ProFTPD
80/tcp   open   http      Apache/2
110/tcp  open   pop3      Dovecot DirectAdmin pop3d
143/tcp  open   imap      Dovecot imapd
443/tcp  open   ssl/https Apache/2
465/tcp  open   ssl/smtp  Exim smtpd 4.98.1
587/tcp  open   smtp      Exim smtpd 4.98.1
993/tcp  open   imaps?
995/tcp  open   pop3s?
2222/tcp open   ssl/http  Golang net/http server