# Wrapistry Gift Wrapping and Calligraphy Company

Tags: +- bug in cart
+-: Not started
ADMIN PANEL: Not started
C2S: Not started
Gateway: payu
SQLI: Not started
Tamper: Not started
trick : need to add in cart and intercept