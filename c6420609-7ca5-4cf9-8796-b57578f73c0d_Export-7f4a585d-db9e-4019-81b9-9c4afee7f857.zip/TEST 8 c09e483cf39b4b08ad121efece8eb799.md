# TEST 8

Date: November 10, 2024
Tags: Not started

PHY - EMI , AC , EM waves , Semiconductors

Chem - Solid State , Solutions , Coordination

Maths - Functions , Limits , Differentiation

Marks Obtained - Paper 1 

| PAPER | PHY | CHEM | MATHS | TOTAL | MAX  |
| --- | --- | --- | --- | --- | --- |
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |