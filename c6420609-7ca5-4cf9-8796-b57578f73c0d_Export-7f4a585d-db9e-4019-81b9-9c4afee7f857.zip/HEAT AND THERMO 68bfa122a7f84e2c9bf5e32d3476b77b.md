# HEAT AND THERMO

1 TIME: Not started
PYQ: Not started